export type Ordre =
	| 'Monotrèmes'
	| 'Marsupiaux'
	| 'Xénarthres'
	| 'Pholidotes'
	| 'Insectivores'
	| 'Carnivores'
	| 'Chiroptères'
	| 'Cétacés';
