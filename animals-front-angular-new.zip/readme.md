[ ]. Créer la classe modèle "Animal"
[ ]. Affichage d'un animal : création d'un web component
[ ]. Suppression d'un animal
[ ]. Création d'un animal : création d'un web component qui présente le formulaire
[ ]. Modification d'un animal
=> Bonus : gérer une notion de "peuplement" par animal